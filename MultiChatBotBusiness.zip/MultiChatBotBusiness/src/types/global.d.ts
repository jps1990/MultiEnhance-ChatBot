interface Window {
  webkitSpeechRecognition: any;
} 