export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  type: 'text' | 'image' | 'error';
  imageUrl?: string;
  timestamp: number;
}

export interface Conversation {
  id: number;
  title: string;
  messages: Message[];
}

export interface ApiKeys {
  openai: string;
  anthropic: string;
  cohere: string;
}

export interface ImageSettings {
  size: '1024x1024' | '1024x1792' | '1792x1024';
  quality: 'standard' | 'hd';
  style: 'natural' | 'vivid';
}

export interface Settings {
  apiKeys: ApiKeys;
  temperature: number;
  systemPrompt: string;
  userPrompt: string;
  maxTokens: number;
  imageSettings: {
    size: string;
    quality: string;
    style: string;
  };
  lastUpdated?: number;
}

export interface ApiResponse {
  content: string;
  type: 'text' | 'image' | 'error';
  imageUrl?: string; // Optional URL for generated images
}