import { jailbreakPrompt } from './jailbreakPrompt';

export { jailbreakPrompt };