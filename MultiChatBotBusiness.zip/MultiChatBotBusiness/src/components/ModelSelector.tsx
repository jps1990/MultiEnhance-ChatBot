import React from 'react';
import { models } from '../utils/models';

interface ModelSelectorProps {
  provider: string;
  model: string;
  onProviderChange: (provider: string) => void;
  onModelChange: (model: string) => void;
  imageSize: string;
  onImageSizeChange: (size: string) => void;
  imageQuality: 'standard' | 'hd';
  onImageQualityChange: (quality: 'standard' | 'hd') => void;
  imageStyle: 'natural' | 'vivid';
  onImageStyleChange: (style: 'natural' | 'vivid') => void;
}

const DALLE_PRICES = {
  'dall-e-3': {
    standard: {
      '1024x1024': 0.04,
      '1024x1792': 0.08,
      '1792x1024': 0.08
    },
    hd: {
      '1024x1024': 0.08,
      '1024x1792': 0.12,
      '1792x1024': 0.12
    }
  },
  'dall-e-2': {
    standard: {
      '1024x1024': 0.02,
      '512x512': 0.018,
      '256x256': 0.016
    }
  }
};

export const ModelSelector: React.FC<ModelSelectorProps> = ({
  provider,
  model,
  onProviderChange,
  onModelChange,
  imageSize,
  onImageSizeChange,
  imageQuality,
  onImageQualityChange,
  imageStyle,
  onImageStyleChange
}) => {
  const isDalleModel = model.includes('dall-e');

  const getCurrentPrice = () => {
    if (!isDalleModel) return null;
    const version = model === 'dall-e-3' ? 'dall-e-3' : 'dall-e-2';
    const quality = imageQuality as 'standard' | 'hd';
    
    if (version === 'dall-e-2') {
      return DALLE_PRICES[version].standard[imageSize] || 0;
    }
    
    return DALLE_PRICES[version][quality][imageSize] || 0;
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <select
        value={provider}
        onChange={(e) => onProviderChange(e.target.value)}
        className="p-2 rounded bg-gray-700 text-white"
      >
        <option value="openai">OpenAI</option>
        <option value="anthropic">Anthropic</option>
        <option value="cohere">Cohere</option>
      </select>

      <select
        value={model}
        onChange={(e) => onModelChange(e.target.value)}
        className="p-2 rounded bg-gray-700 text-white"
      >
        {models[provider as keyof typeof models]?.map((m) => (
          <option key={m} value={m}>{m}</option>
        ))}
      </select>

      {isDalleModel && (
        <>
          <div className="flex items-center gap-4">
            <div className="flex flex-col gap-2">
              <select
                value={imageSize}
                onChange={(e) => onImageSizeChange(e.target.value)}
                className="p-2 rounded bg-gray-700 text-white"
              >
                <option value="1024x1024">Carré (1024x1024)</option>
                <option value="1024x1792">Portrait (1024x1792)</option>
                <option value="1792x1024">Paysage (1792x1024)</option>
              </select>

              <select
                value={imageQuality}
                onChange={(e) => onImageQualityChange(e.target.value as 'standard' | 'hd')}
                className="p-2 rounded bg-gray-700 text-white"
              >
                <option value="standard">Standard</option>
                <option value="hd">HD</option>
              </select>

              <select
                value={imageStyle}
                onChange={(e) => onImageStyleChange(e.target.value as 'natural' | 'vivid')}
                className="p-2 rounded bg-gray-700 text-white"
              >
                <option value="natural">Natural</option>
                <option value="vivid">Vivid</option>
              </select>
            </div>
            
            <div className="bg-gray-800 p-3 rounded-lg">
              {/* Add your price display logic here */}
            </div>
          </div>
        </>
      )}
    </div>
  );
};