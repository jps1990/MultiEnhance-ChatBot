# Enhanced-Multi-Provider-Chatbot-Business-Edition
 Chatbot Business Edition

Français en dessous du texte en anglais

#README.md - MultiChatBot Business 🤖

Damn! Alright, let’s keep it simple and straight to the point!
What’s this thing? 🤔
A multi-model chatbot with local API key encryption. It can:

-Manage OpenAI, Anthropic, and Cohere
-Generate images with DALL-E
-Chat in voice
-Save conversations locally
-Encrypt API keys in the browser storage


#Installation 🛠️

//Clone the repo

npm install (and wait till it’s done)

//Create a .env file with:

makefile

//Copier le code

VITE_ENCRYPTION_KEY=your-32-character-encryption-key


#Development 🚀

npm run dev - Start the development server
npm run build - Build for production
npm run preview - Preview the build
#Features 🌟

##Supported Models

OpenAI: GPT-4o, GPT-4-turbo, GPT-4, GPT-3.5-turbo, DALL-E 3/2
Anthropic: The entire Claude 3 family (Opus, Sonnet, Haiku)
Cohere: Command, Command-Light, Command-R


##Smart Settings

Chit-Chat 🗣️

Temperature: 0.7-0.9
Adjusted penalties for natural conversation
Code Chat 💻

Temperature: 0.1-0.3
Minimal penalties for precise code
Professor Chat 📚

Temperature: 0.4-0.6
Balance between accuracy and creativity
##Jailbreak Mode 😈

Special mode with temperature at 1
More free and creative responses
Activated with a dedicated button
#Security 🔒

Local encryption of API keys with CryptoJS
Secure storage in localStorage
Protection against key leaks
NEVER hard-code keys in the code
#Project Structure 📁

bash
Copier le code
src/
├── components/     # React components
├── utils/          # Utilities + encryption
├── types/          # TypeScript types
└── App.tsx         # Main component
#Contribution 🤝

Fork the repo
Create a branch
Push your changes
Open a PR
Golden Rules:

Don’t touch encryption
Test BEFORE pushing
No stray console.logs
NEVER hard-code API keys
License 📄

MIT (Do what you want, but own it!)

#IMPORTANT NOTES:

Encryption key is MANDATORY
API keys are entered by users in the app
Everything is encrypted locally
Conversations are saved in localStorage
#REMINDERS:

Back up your data regularly
Keep your encryption key secret
If you break the encryption, it’s YOUR problem!

_______________________________________________

FRANCAIS

#README.md - MultiChatBot Entreprise 🤖

Tabarnak! Ok, on y va simple pis direct!
C'est quoi c't'affaire-là? 🤔
Un chatbot multi-modèles avec encryption locale des API keys. Y peut:
Gérer OpenAI, Anthropic pis Cohere
Générer des images avec DALL-E
Jaser en vocal
Sauvegarder les conversations localement
Encrypter les API keys dans le storage du browser


#Installation 🛠️

Clone le repo
npm install (pis attends que ça finisse)
Crée un fichier .env avec:

VITE_ENCRYPTION_KEY=ta-clé-d-encryption-32-caractères

#Développement 🚀

npm run dev - Lance le serveur de dev
npm run build - Build pour la prod
npm run preview - Preview la build

#Features 🌟

#Modèles Supportés

1.OpenAI: GPT-4o, GPT-4-turbo, GPT-4, GPT-3.5-turbo, DALL-E 3/2
2.Anthropic: Toute la famille Claude 3 (Opus, Sonnet, Haiku)
3.Cohere: Command, Command-Light, Command-R

#Paramètres Intelligents

1. Chat Bavard 🗣️
Temperature: 0.7-0.9
Pénalités ajustées pour une conversation naturelle

2.Chat Code 💻
Temperature: 0.1-0.3
Pénalités minimales pour du code précis

3.Chat Prof 📚
Temperature: 0.4-0.6
Balance entre précision et créativité

Mode Jailbreak 😈

Mode spécial avec température à 1
Réponses plus libres et créatives
Activation par bouton dédié

#Sécurité 🔒

Encryption locale des API keys avec CryptoJS
Stockage sécurisé dans le localStorage
Protection contre les fuites de clés
JAMAIS de clés en dur dans le code

#Structure du Projet 📁

src/
├── components/     # Components React
├── utils/         # Utilitaires + encryption
├── types/         # Types TypeScript
└── App.tsx        # Component principal


#Contribution 🤝

Fork le repo
Crée une branche
Push tes changes
Ouvre une PR

Règles d'or:

Touche pas à l'encryption
Teste AVANT de pusher
Pas de console.log qui traîne
Pas d'API keys en dur JAMAIS

License 📄

MIT (Fais-en c'que tu veux, mais assume!)

---

#NOTES IMPORTANTES:

La clé d'encryption est OBLIGATOIRE
Les API keys sont entrées par les users dans l'app
Tout est encrypté localement
Les conversations sont sauvegardées dans le localStorage

#RAPPELS:

Backup tes données régulièrement
Garde ta clé d'encryption secrète
Si tu casses l'encryption, c'est TON problème!

