import React, { useState } from 'react';
import { Message } from '../types';
import { Bot, User, Volume2, VolumeX } from 'lucide-react';
import { ImageModal } from './ImageModal';

interface ChatMessageProps {
  message: Message;
  onSpeak: (text: string) => void;
  isSpeaking: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onSpeak, isSpeaking }) => {
  const [showImageModal, setShowImageModal] = useState(false);
  const { role, content, type = 'text', imageUrl } = message;
  const isUser = role === 'user';

  const handleDownload = async (url: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `image-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  const renderContent = () => {
    switch (type) {
      case 'image':
        return (
          <div className="space-y-2">
            <p>{content}</p>
            {imageUrl && (
              <div className="relative group">
                <img 
                  src={imageUrl} 
                  alt="Generated content"
                  className="max-w-full rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => setShowImageModal(true)}
                />
              </div>
            )}
            {showImageModal && imageUrl && (
              <ImageModal 
                imageUrl={imageUrl} 
                onClose={() => setShowImageModal(false)} 
              />
            )}
          </div>
        );
      case 'error':
        return <p className="text-red-400">{content}</p>;
      default:
        return <p className="whitespace-pre-wrap">{content}</p>;
    }
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex items-start space-x-2 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`p-2 rounded-full ${isUser ? 'bg-blue-600' : 'bg-gray-700'}`}>
          {isUser ? <User size={24} /> : <Bot size={24} />}
        </div>
        <div className={`p-3 rounded-lg ${isUser ? 'bg-blue-500' : 'bg-gray-800'} max-w-md relative`}>
          {renderContent()}
          {!isUser && type === 'text' && (
            <button 
              onClick={() => onSpeak(content)}
              className={`p-1 rounded hover:bg-blue-900/20 ${isSpeaking ? 'text-blue-400' : ''}`}
              title={isSpeaking ? 'En train de parler' : 'Écouter'}
            >
              {isSpeaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;