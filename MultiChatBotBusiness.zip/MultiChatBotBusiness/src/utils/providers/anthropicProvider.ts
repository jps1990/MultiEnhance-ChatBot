import axios from 'axios';

export const makeAnthropicRequest = async (
  model: string,
  prompt: string,
  apiKey: string
) => {
  const headers = {
    'anthropic-version': '2024-01-01',
    'x-api-key': apiKey,
    'content-type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-api-key, anthropic-version'
  };

  try {
    const response = await axios.post(
      'https://api.anthropic.com/v1/messages',
      {
        model,
        messages: [{
          role: 'user',
          content: prompt
        }],
        max_tokens: 1024
      },
      { 
        headers,
        withCredentials: false
      }
    );

    return {
      data: {
        choices: [{
          message: {
            content: response.data.content[0].text
          }
        }]
      }
    };
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw {
        message: error.response.data.error?.message || 'Anthropic API error',
        status: error.response.status,
        data: error.response.data
      };
    }
    throw error;
  }
};